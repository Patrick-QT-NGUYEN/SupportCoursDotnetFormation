﻿using EFCORE_Basics.Classes;

new IHM().Run();