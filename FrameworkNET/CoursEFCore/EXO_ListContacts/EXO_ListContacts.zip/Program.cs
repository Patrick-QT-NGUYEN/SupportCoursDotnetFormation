﻿using EXO_ListContacts.Classes;

new IHM().Run();