﻿using EFCORE_Liaisons.Classes;

new IHM().Run();